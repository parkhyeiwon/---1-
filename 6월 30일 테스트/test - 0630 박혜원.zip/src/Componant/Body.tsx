import React from 'react'
import './Body.css';
import { styled } from 'styled-components';


const Submitarea = styled.div`
  display:flex;
  flex-direction:row;
  justify-content: center;
  align-items:center;
`

const Button = styled.button`
  width:18rem;
  height:3rem;
  margin-top:1rem;
  border: 1px solid #0055FF;
  border-radius: 8px;
  color:#0055FF;
  font-size:13px;
  background-color: white;
`

const Body = () => {
  return (
    <div>
      <h1 style={{color:"#0055FF"}}>회원가입을 위해<br/>정보를 입력해주세요</h1>
      <div className='textinp-area'>
        <p>*이메일</p>
        <input type="text" />
        <p>*이름</p>
        <input type="text" />
        <p>*비밀번호</p>
        <input type="text" />
        <p>*비밀번호 확인</p>
        <input type="text" />
      </div>
      <div className='bottom-area'>
        <div className='check-area'>
          <input type="radio" />
            <label>여성</label>
            <input type="radio" />
            <label>남성</label>
        </div>
        <div className='agree-area'>
          <input type="checkbox" />
          <label>이용약관 개인정보 수집 및 이용, 마케팅 활용 선택에 모두 동의합니다.</label>
        </div>
      </div>
        <hr/>
      <Submitarea>
        <Button>가입하기</Button>
      </Submitarea>
    </div>
  )
}

export default Body
