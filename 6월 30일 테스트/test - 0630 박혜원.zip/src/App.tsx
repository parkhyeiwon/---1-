import React from 'react';
import logo from './logo.svg';
import './App.css';
import Body from './Componant/Body';
import { styled } from 'styled-components';

const Container = styled.div`
  display:flex;
  flex-direction:row;
  justify-content:center;
  align-items:center;
  height:100vh;
`
const Inner = styled.div`
  border: 1px solid #0055FF;
  width: 35rem;
  height:100vh;
  display:flex;
  padding: 30px;
  justify-content: flex-start;
  align-items:center;
  flex-direction: column;
`

function App() {
  return (
    <Container>
      <Inner>
        <Body />
      </Inner>
    </Container>
  );
}

export default App;
