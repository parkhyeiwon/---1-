const saveBtn = document.querySelector(".btnSave")
const loadBtn= document.querySelector(".btnRead")
const text = document.querySelector(".text")


saveBtn.addEventListener("click", () => {
  let usertext = text.value
})