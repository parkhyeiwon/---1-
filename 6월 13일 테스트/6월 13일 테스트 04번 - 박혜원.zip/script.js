let loG = document.querySelector("#log")

import { textOne } from "./MyClass1"
import { textTwo } from "./MyClass2"
