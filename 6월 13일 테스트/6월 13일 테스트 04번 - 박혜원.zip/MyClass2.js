export const textTwo = loG.innerText("항상 그렇듯 늘 파이팅 입니다!")
