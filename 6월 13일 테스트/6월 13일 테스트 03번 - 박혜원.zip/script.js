const saveBtn = document.querySelector(".btnSave")
const removeBtn= document.querySelector(".btnRemove")
const text = document.querySelector(".btnClear")


saveBtn.addEventListener("click", () => {
  let usertext = text.value

})


removeBtn.addEventListener("click", () => {
  localStorage.clear()
})