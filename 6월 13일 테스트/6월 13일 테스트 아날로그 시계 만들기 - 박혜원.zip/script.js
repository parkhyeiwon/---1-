
setInterval(() => {
  let today = new Date();

  let h = today.getHours();
  let m = today.getMinutes();
  let s = today.getSeconds();

  let lineH = document.querySelector(".lineHour")
  let lineM = document.querySelector(".lineMin")
  let lineS = document.querySelector(".lineSec")

  let degH = h * (360 / 12) + m * (360 / 12 / 60)
  let degM = m * (360 / 60)
  let degS = s * (360 / 60)

  lineH.style.transform = `rotate(${degH}deg)`
  lineM.style.transform = `rotate(${degM}deg)`
  lineS.style.transform = `rotate(${degS}deg)`

}, 1000)

