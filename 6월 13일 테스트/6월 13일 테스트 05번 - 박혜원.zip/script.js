
let load = document.querySelector("button")
let log = document.querySelector(".log")

fetch("./05/comment.js")
  .then((res) => {
    return res.json()
  })
  .then((obj) => {
    List(obj)
  })

  