// let lang = new Set(["js", "c", "python", "c", "js"]);
// for (let el of lang.values()) {
//   console.log(el)
// }

//-----------------------------------
//
// const member1 = ["HTML", "CSS"]
// const member2 = ["HTML", "Javascript", "React"]
// const member3 = ["Javascript", "Typescript"]

// const subjects = [...member1, ...member2, ...member3];
// // console.log(subjects);

// const resultList = new Set();
// subjects.forEach(subject => {
//   resultList.add(subject)
// })
// console.log(resultList);

// const result = document.querySelector("#result")
// result.innerHTML = `
//   <ul>
//   ${[...resultList]
//     .map(subject => `<li>${subject}</li>`)
//     .join("")}
//   </ul>
// `;


// *html
// <div id="container"></div>
// <h1>신청과목</h1>
// <ul>
//   <li>유동하 : HTML, CSS</li>
//   <li>민유진 : CSS, Javascript, React</li>
//   <li>장동성 : Javascript, Typescript</li>
// </ul>
// <hr />
// <h2>최종신청과목</h2>
// <div id="result"></div>

//*css
// #container {
//   width: 400px;
//   margin: 20px auto;
// }

// hr {
//   width: 100%;
//   border: 1px dotted #222;
// }
// ul {
//   list-style: none;
// }
// li {
//   font-size: 1rem;
//   line-height: 2;
// }
//--------------------------------
const result = document.querySelector("#result");
const button = document.querySelector("button")

const luckyNumber = {
  digitCount : 6,
  maxNumber : 45
}

button.addEventListener("click", () => {
  let {digitCount, maxNumber} = luckyNumber;
  let myNumber = new Set();
  for(let i = 0; i < digitCount; i++) {
    myNumber.add(Math.floor((Math.random() * maxNumber) + 1));
  }
  result.innerText = `${[...myNumber]}`;
})